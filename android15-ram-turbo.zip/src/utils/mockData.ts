import { AppProcess, DeviceProfile, RAMStats, BenchmarkMetrics, TurboGamePackage } from '../types';

export const DEVICE_PROFILES: DeviceProfile[] = [
  {
    id: 'pixel-9-pro',
    name: 'Google Pixel 9 Pro XL (Android 15)',
    model: 'Pixel 9 Pro XL (komodo)',
    chipset: 'Google Tensor G4 (Titan M2 Security)',
    totalRamGb: 16,
    defaultSwapGb: 8,
    kernelVersion: 'Linux 6.1.75-android15-11-gec87e14',
    androidVersion: 'Android 15 (Vanilla Ice Cream)',
    apiLevel: 35,
    supports16kbPage: true,
  },
  {
    id: 'galaxy-s24-ultra',
    name: 'Samsung Galaxy S24 Ultra (One UI 7 / A15)',
    model: 'SM-S928B (Snapdragon 8 Gen 3)',
    chipset: 'Qualcomm Snapdragon 8 Gen 3 for Galaxy',
    totalRamGb: 12,
    defaultSwapGb: 8,
    kernelVersion: 'Linux 6.1.68-qcom-android15',
    androidVersion: 'Android 15 (One UI 7.0)',
    apiLevel: 35,
    supports16kbPage: true,
  },
  {
    id: 'xiaomi-14-ultra',
    name: 'Xiaomi 14 Ultra (HyperOS 2.0 / A15)',
    model: '24030PN60G (aurora)',
    chipset: 'Qualcomm Snapdragon 8 Gen 3',
    totalRamGb: 16,
    defaultSwapGb: 6,
    kernelVersion: 'Linux 6.1.55-android15-perf',
    androidVersion: 'Android 15 (Xiaomi HyperOS 2)',
    apiLevel: 35,
    supports16kbPage: true,
  },
  {
    id: 'rog-phone-8',
    name: 'ASUS ROG Phone 8 Pro (Gaming Beast)',
    model: 'ASUS_AI2401_D',
    chipset: 'Qualcomm Snapdragon 8 Gen 3 (Overclocked)',
    totalRamGb: 24,
    defaultSwapGb: 12,
    kernelVersion: 'Linux 6.1.80-android15-rog-turbo',
    androidVersion: 'Android 15 (ROG UI)',
    apiLevel: 35,
    supports16kbPage: true,
  },
  {
    id: 'generic-midrange',
    name: 'Thiết bị Android 15 Tiêu Chuẩn (8GB RAM)',
    model: 'Generic ARM64 v9 Device',
    chipset: 'MediaTek Dimensity 8300 Ultra',
    totalRamGb: 8,
    defaultSwapGb: 4,
    kernelVersion: 'Linux 6.1.42-android15-generic',
    androidVersion: 'Android 15 (Stock AOSP)',
    apiLevel: 35,
    supports16kbPage: true,
  },
];

export const INITIAL_PROCESSES: AppProcess[] = [
  {
    id: 'proc-1',
    name: 'Genshin Impact (MiHoYo)',
    packageName: 'com.miHoYo.GenshinImpact',
    category: 'games',
    ramUsageMb: 1420,
    initialRamMb: 1420,
    cpuPercent: 18.5,
    priority: 'foreground',
    isProtected: false,
    isFrozen: false,
    isKilled: false,
    canKill: true,
    page16kbAligned: true,
  },
  {
    id: 'proc-2',
    name: 'TikTok',
    packageName: 'com.zhiliaoapp.musically',
    category: 'social',
    ramUsageMb: 760,
    initialRamMb: 760,
    cpuPercent: 8.4,
    priority: 'cached',
    isProtected: false,
    isFrozen: false,
    isKilled: false,
    canKill: true,
    page16kbAligned: true,
  },
  {
    id: 'proc-3',
    name: 'Facebook & Messenger Services',
    packageName: 'com.facebook.katana',
    category: 'social',
    ramUsageMb: 685,
    initialRamMb: 685,
    cpuPercent: 6.2,
    priority: 'service',
    isProtected: false,
    isFrozen: false,
    isKilled: false,
    canKill: true,
    page16kbAligned: false,
  },
  {
    id: 'proc-4',
    name: 'Google Chrome (14 tabs)',
    packageName: 'com.android.chrome',
    category: 'tools',
    ramUsageMb: 890,
    initialRamMb: 890,
    cpuPercent: 4.8,
    priority: 'cached',
    isProtected: false,
    isFrozen: false,
    isKilled: false,
    canKill: true,
    page16kbAligned: true,
  },
  {
    id: 'proc-5',
    name: 'Zalo Chat & Sync',
    packageName: 'com.zing.zalo',
    category: 'social',
    ramUsageMb: 410,
    initialRamMb: 410,
    cpuPercent: 1.5,
    priority: 'service',
    isProtected: true, // Whitelisted by default to protect messages
    isFrozen: false,
    isKilled: false,
    canKill: true,
    page16kbAligned: true,
  },
  {
    id: 'proc-6',
    name: 'YouTube 4K Buffer',
    packageName: 'com.google.android.youtube',
    category: 'media',
    ramUsageMb: 530,
    initialRamMb: 530,
    cpuPercent: 3.1,
    priority: 'cached',
    isProtected: false,
    isFrozen: false,
    isKilled: false,
    canKill: true,
    page16kbAligned: true,
  },
  {
    id: 'proc-7',
    name: 'Shopee Online Shopping',
    packageName: 'com.shopee.vn',
    category: 'shopping',
    ramUsageMb: 375,
    initialRamMb: 375,
    cpuPercent: 2.2,
    priority: 'cached',
    isProtected: false,
    isFrozen: false,
    isKilled: false,
    canKill: true,
    page16kbAligned: false,
  },
  {
    id: 'proc-8',
    name: 'Spotify Music Daemon',
    packageName: 'com.spotify.music',
    category: 'media',
    ramUsageMb: 295,
    initialRamMb: 295,
    cpuPercent: 1.8,
    priority: 'service',
    isProtected: false,
    isFrozen: false,
    isKilled: false,
    canKill: true,
    page16kbAligned: true,
  },
  {
    id: 'proc-9',
    name: 'Liên Quân Mobile (Arena of Valor)',
    packageName: 'com.garena.game.kgvn',
    category: 'games',
    ramUsageMb: 980,
    initialRamMb: 980,
    cpuPercent: 0.1,
    priority: 'cached',
    isProtected: false,
    isFrozen: false,
    isKilled: false,
    canKill: true,
    page16kbAligned: true,
  },
  {
    id: 'proc-10',
    name: 'Android 15 SystemUI & SurfaceFlinger',
    packageName: 'com.android.systemui',
    category: 'system',
    ramUsageMb: 820,
    initialRamMb: 820,
    cpuPercent: 2.9,
    priority: 'foreground',
    isProtected: true,
    isFrozen: false,
    isKilled: false,
    canKill: false,
    page16kbAligned: true,
  },
  {
    id: 'proc-11',
    name: 'Google Play Services (GMS Core)',
    packageName: 'com.google.android.gms',
    category: 'system',
    ramUsageMb: 460,
    initialRamMb: 460,
    cpuPercent: 1.7,
    priority: 'service',
    isProtected: true,
    isFrozen: false,
    isKilled: false,
    canKill: false,
    page16kbAligned: true,
  },
  {
    id: 'proc-12',
    name: 'Phantom Background Analytics Tracer',
    packageName: 'com.android.traceur.phantom',
    category: 'system',
    ramUsageMb: 245,
    initialRamMb: 245,
    cpuPercent: 3.5,
    priority: 'phantom',
    isProtected: false,
    isFrozen: false,
    isKilled: false,
    canKill: true,
    page16kbAligned: false,
  },
  {
    id: 'proc-13',
    name: 'Camera ISP Buffer Daemon',
    packageName: 'vendor.qti.hardware.camera.provider',
    category: 'system',
    ramUsageMb: 512,
    initialRamMb: 512,
    cpuPercent: 0.4,
    priority: 'service',
    isProtected: false,
    isFrozen: false,
    isKilled: false,
    canKill: true,
    page16kbAligned: true,
  },
  {
    id: 'proc-14',
    name: 'Telegram Messenger',
    packageName: 'org.telegram.messenger',
    category: 'social',
    ramUsageMb: 340,
    initialRamMb: 340,
    cpuPercent: 1.1,
    priority: 'cached',
    isProtected: true,
    isFrozen: false,
    isKilled: false,
    canKill: true,
    page16kbAligned: true,
  },
];

export const DEFAULT_GAMES_LIST: TurboGamePackage[] = [
  {
    id: 'com.garena.game.kgvn',
    packageName: 'com.garena.game.kgvn',
    name: 'Liên Quân Mobile (Arena of Valor)',
    icon: '⚔️',
    dedicatedRamGb: 4,
    targetFps: 120,
    isCustom: false,
  },
  {
    id: 'com.dts.freefireth',
    packageName: 'com.dts.freefireth',
    name: 'Free Fire MAX',
    icon: '🔥',
    dedicatedRamGb: 4,
    targetFps: 90,
    isCustom: false,
  },
  {
    id: 'com.vng.pubgmobile',
    packageName: 'com.vng.pubgmobile',
    name: 'PUBG Mobile VN',
    icon: '🎯',
    dedicatedRamGb: 6,
    targetFps: 90,
    isCustom: false,
  },
  {
    id: 'com.miHoYo.GenshinImpact',
    packageName: 'com.miHoYo.GenshinImpact',
    name: 'Genshin Impact',
    icon: '✨',
    dedicatedRamGb: 6,
    targetFps: 60,
    isCustom: false,
  },
  {
    id: 'com.riotgames.league.wildrift',
    packageName: 'com.riotgames.league.wildrift',
    name: 'LMHT: Tốc Chiến (Wild Rift)',
    icon: '🏆',
    dedicatedRamGb: 4,
    targetFps: 120,
    isCustom: false,
  },
];

export const GAMES_LIST = DEFAULT_GAMES_LIST;

export function computeRAMStats(device: DeviceProfile, processes: AppProcess[], virtualRamGb: number, swappiness: number, zramAlgorithm: 'LZ4' | 'ZSTD' | 'LZO-RLE'): RAMStats {
  const totalMb = device.totalRamGb * 1024;
  
  // Calculate process active and cached sum
  let activeProcMb = 0;
  let cachedProcMb = 0;

  processes.forEach(p => {
    if (p.isKilled) return;
    const effectiveMb = p.isFrozen ? Math.round(p.ramUsageMb * 0.15) : p.ramUsageMb;
    if (p.priority === 'cached' || p.priority === 'phantom') {
      cachedProcMb += effectiveMb;
    } else {
      activeProcMb += effectiveMb;
    }
  });

  const kernelMb = Math.round(totalMb * 0.12); // ~12% kernel + hardware reserves
  const activeMb = activeProcMb;
  const cachedMb = cachedProcMb;
  const usedMb = Math.min(totalMb - 512, kernelMb + activeMb + cachedMb);
  const freeMb = Math.max(256, totalMb - usedMb);

  const zramTotalMb = virtualRamGb * 1024;
  // Estimate swap usage based on cached processes and swappiness
  const zramUsedMb = Math.min(
    zramTotalMb * 0.9,
    Math.round((cachedMb * (swappiness / 100)) * (zramAlgorithm === 'ZSTD' ? 0.38 : 0.52))
  );

  // Android 15 16KB fragmentation is lower (typically 4-15%)
  const unalignedCount = processes.filter(p => !p.isKilled && !p.page16kbAligned).length;
  const fragmentationPercent = Math.min(48, 6 + unalignedCount * 5);

  return {
    totalMb,
    usedMb,
    freeMb,
    cachedMb,
    activeMb,
    kernelMb,
    zramTotalMb,
    zramUsedMb,
    zramAlgorithm,
    swappiness,
    pageSizeKb: 16,
    fragmentationPercent,
  };
}

export const INITIAL_BENCHMARK: BenchmarkMetrics = {
  readSpeedGbps: 46.2,
  writeSpeedGbps: 38.7,
  latencyNs: 42.4,
  fragmentationPercent: 14.5,
  page16kbScore: 94,
  overallScore: 89,
  testedAt: null,
};
