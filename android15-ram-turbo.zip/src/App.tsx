import { useState, useMemo, useEffect } from 'react';
import {
  AppProcess,
  DeviceProfile,
  AppSettings,
  BoostResult,
  BenchmarkMetrics,
  CompressionAlgorithm,
  LmkMode,
  TurboGamePackage,
} from './types';
import {
  DEVICE_PROFILES,
  INITIAL_PROCESSES,
  INITIAL_BENCHMARK,
  DEFAULT_GAMES_LIST,
  computeRAMStats,
} from './utils/mockData';
import { soundFX } from './utils/audio';
import { AndroidStatusBar } from './components/AndroidStatusBar';
import { Navigation, TabType } from './components/Navigation';
import { BoostModal } from './components/BoostModal';
import { QuickBoostTab } from './components/Tabs/QuickBoostTab';
import { ProcessManagerTab } from './components/Tabs/ProcessManagerTab';
import { VirtualRamTab } from './components/Tabs/VirtualRamTab';
import { GameTurboTab } from './components/Tabs/GameTurboTab';
import { BenchmarkTab } from './components/Tabs/BenchmarkTab';
import { SettingsTab } from './components/Tabs/SettingsTab';

export default function App() {
  // Device & Settings State
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>('pixel-9-pro');
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [language, setLanguage] = useState<'vi' | 'en'>('vi');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [viewMode, setViewMode] = useState<'responsive' | 'phone_mockup'>('responsive');

  // Virtual RAM and Kernel state
  const [virtualRamSizeGb, setVirtualRamSizeGb] = useState<number>(8);
  const [zramAlgorithm, setZramAlgorithm] = useState<CompressionAlgorithm>('ZSTD');
  const [swappiness, setSwappiness] = useState<number>(60);
  const [lmkMode, setLmkMode] = useState<LmkMode>('balanced');

  // Game Turbo state
  const [gameTurboActive, setGameTurboActive] = useState<boolean>(false);
  const [gamesList, setGamesList] = useState<TurboGamePackage[]>(() => {
    try {
      const saved = localStorage.getItem('android15_turbo_games');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // Ignore
    }
    return DEFAULT_GAMES_LIST;
  });
  const [selectedGame, setSelectedGame] = useState<string | null>(DEFAULT_GAMES_LIST[0].id);

  // Sync games list to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('android15_turbo_games', JSON.stringify(gamesList));
    } catch {
      // Ignore
    }
  }, [gamesList]);

  // Automation settings
  const [autoBoostEnabled, setAutoBoostEnabled] = useState<boolean>(true);
  const [autoBoostThresholdPercent, setAutoBoostThresholdPercent] = useState<number>(80);
  const [boostOnScreenLock, setBoostOnScreenLock] = useState<boolean>(false);

  // Processes state
  const [processes, setProcesses] = useState<AppProcess[]>(INITIAL_PROCESSES);

  // Boost modal and status
  const [isBoosting, setIsBoosting] = useState<boolean>(false);
  const [isBoostModalOpen, setIsBoostModalOpen] = useState<boolean>(false);
  const [lastBoostResult, setLastBoostResult] = useState<BoostResult | null>(null);

  // Benchmark stats
  const [benchmark, setBenchmark] = useState<BenchmarkMetrics>(INITIAL_BENCHMARK);

  // Current Device
  const currentDevice = useMemo(() => {
    return DEVICE_PROFILES.find((d) => d.id === selectedDeviceId) || DEVICE_PROFILES[0];
  }, [selectedDeviceId]);

  // Compute live RAM statistics
  const stats = useMemo(() => {
    return computeRAMStats(currentDevice, processes, virtualRamSizeGb, swappiness, zramAlgorithm);
  }, [currentDevice, processes, virtualRamSizeGb, swappiness, zramAlgorithm]);

  // Sync sound setting with Web Audio engine
  useEffect(() => {
    soundFX.setEnabled(soundEnabled);
  }, [soundEnabled]);

  // Trigger Master Boost
  const handleTriggerBoost = () => {
    setIsBoosting(true);
    soundFX.playWhoosh();

    const previousUsed = stats.usedMb;

    // Simulate killing all unwhitelisted cached & phantom processes
    setTimeout(() => {
      let freed = 0;
      let closedCount = 0;

      setProcesses((prev) =>
        prev.map((p) => {
          if (!p.isProtected && p.canKill && (p.priority === 'cached' || p.priority === 'phantom')) {
            freed += p.ramUsageMb;
            closedCount += 1;
            return { ...p, isKilled: true, isFrozen: false };
          }
          return p;
        })
      );

      const compactedZram = Math.round(stats.zramUsedMb * 0.45);
      const totalFreed = freed + compactedZram;

      const result: BoostResult = {
        freedMb: totalFreed > 0 ? totalFreed : 1850,
        appsClosed: closedCount > 0 ? closedCount : 5,
        zramCompactedMb: compactedZram > 0 ? compactedZram : 940,
        previousUsedMb: previousUsed,
        newUsedMb: Math.max(1024, previousUsed - totalFreed),
        durationMs: 1400,
        timestamp: new Date(),
      };

      setLastBoostResult(result);
      setIsBoosting(false);
      setIsBoostModalOpen(true);
    }, 900);
  };

  // Quick action handling from tiles
  const handleQuickAction = (actionType: 'cache' | 'phantom' | '16kb' | 'zram') => {
    if (actionType === 'cache') {
      let freed = 0;
      setProcesses((prev) =>
        prev.map((p) => {
          if (p.priority === 'cached' && !p.isProtected && p.canKill) {
            freed += p.ramUsageMb;
            return { ...p, isKilled: true };
          }
          return p;
        })
      );
      soundFX.playBoostComplete();
    } else if (actionType === 'phantom') {
      setProcesses((prev) =>
        prev.map((p) => {
          if (p.priority === 'phantom' && p.canKill) {
            return { ...p, isKilled: true };
          }
          return p;
        })
      );
      soundFX.playBoostComplete();
    } else if (actionType === '16kb') {
      // Defragment 16KB pages
      setProcesses((prev) =>
        prev.map((p) => ({ ...p, page16kbAligned: true }))
      );
      soundFX.playBoostComplete();
    } else if (actionType === 'zram') {
      soundFX.playBoostComplete();
    }
  };

  // Process item actions
  const handleToggleProtect = (id: string) => {
    setProcesses((prev) =>
      prev.map((p) => (p.id === id ? { ...p, isProtected: !p.isProtected } : p))
    );
  };

  const handleToggleFreeze = (id: string) => {
    setProcesses((prev) =>
      prev.map((p) => (p.id === id ? { ...p, isFrozen: !p.isFrozen } : p))
    );
  };

  const handleKillProcess = (id: string) => {
    setProcesses((prev) =>
      prev.map((p) => (p.id === id ? { ...p, isKilled: true, isFrozen: false } : p))
    );
  };

  const handleKillAllCached = () => {
    setProcesses((prev) =>
      prev.map((p) => {
        if (!p.isProtected && p.canKill && (p.priority === 'cached' || p.priority === 'phantom')) {
          return { ...p, isKilled: true, isFrozen: false };
        }
        return p;
      })
    );
    soundFX.playBoostComplete();
  };

  const handleResetProcesses = () => {
    setProcesses(INITIAL_PROCESSES);
    soundFX.playTap();
  };

  const handleToggleGameTurbo = () => {
    setGameTurboActive((prev) => {
      const next = !prev;
      if (next) {
        setLmkMode('extreme_gaming');
      } else {
        setLmkMode('balanced');
      }
      return next;
    });
  };

  // Custom Game Package Handlers
  const handleAddCustomGame = (newGame: TurboGamePackage) => {
    setGamesList((prev) => [newGame, ...prev]);
    setSelectedGame(newGame.id);
  };

  const handleUpdateGame = (updatedGame: TurboGamePackage) => {
    setGamesList((prev) =>
      prev.map((g) => (g.id === updatedGame.id ? updatedGame : g))
    );
  };

  const handleDeleteGame = (id: string) => {
    setGamesList((prev) => {
      const filtered = prev.filter((g) => g.id !== id);
      if (selectedGame === id && filtered.length > 0) {
        setSelectedGame(filtered[0].id);
      }
      return filtered;
    });
  };

  const handleRestoreDefaultGames = () => {
    setGamesList(DEFAULT_GAMES_LIST);
    setSelectedGame(DEFAULT_GAMES_LIST[0].id);
    soundFX.playBoostComplete();
  };

  // Device selection
  const handleSelectDevice = (deviceId: string) => {
    setSelectedDeviceId(deviceId);
    const newDev = DEVICE_PROFILES.find((d) => d.id === deviceId);
    if (newDev) {
      setVirtualRamSizeGb(newDev.defaultSwapGb);
    }
    soundFX.playTap();
  };

  const appSettings: AppSettings = {
    language,
    soundEnabled,
    autoBoostEnabled,
    autoBoostThresholdPercent,
    boostOnScreenLock,
    viewMode,
    selectedDeviceId,
    lmkMode,
    page16kbCompaction: true,
    virtualRamSizeGb,
    zramAlgorithm,
    swappiness,
    gameTurboActive,
    selectedGameForTurbo: selectedGame,
  };

  const handleUpdateSettings = (patch: Partial<AppSettings>) => {
    if (patch.autoBoostEnabled !== undefined) setAutoBoostEnabled(patch.autoBoostEnabled);
    if (patch.autoBoostThresholdPercent !== undefined)
      setAutoBoostThresholdPercent(patch.autoBoostThresholdPercent);
    if (patch.boostOnScreenLock !== undefined) setBoostOnScreenLock(patch.boostOnScreenLock);
    if (patch.soundEnabled !== undefined) setSoundEnabled(patch.soundEnabled);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-start antialiased selection:bg-emerald-500 selection:text-black">
      {/* Phone Mockup Wrapper or Fullscreen Responsive */}
      <div
        className={`w-full transition-all duration-300 ${
          viewMode === 'phone_mockup'
            ? 'max-w-[430px] my-6 rounded-[48px] border-8 border-slate-800 shadow-[0_0_60px_rgba(0,0,0,0.8)] overflow-hidden bg-slate-950 ring-1 ring-slate-700/50'
            : 'max-w-2xl min-h-screen border-x border-slate-900 bg-slate-950'
        }`}
      >
        {/* Authentic Android 15 Status Bar */}
        <AndroidStatusBar
          device={currentDevice}
          soundEnabled={soundEnabled}
          onToggleSound={() => setSoundEnabled((prev) => !prev)}
          language={language}
          onToggleLanguage={() => setLanguage((prev) => (prev === 'vi' ? 'en' : 'vi'))}
          viewMode={viewMode}
          onToggleViewMode={() =>
            setViewMode((prev) => (prev === 'phone_mockup' ? 'responsive' : 'phone_mockup'))
          }
        />

        {/* Dynamic Header */}
        <header className="px-5 pt-4 pb-2">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-black text-white tracking-tight">
                  {language === 'vi' ? 'TĂNG TỐC RAM 15' : 'RAM TURBO 15'}
                </h1>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-gradient-to-r from-emerald-500/20 to-cyan-500/20 text-emerald-300 border border-emerald-500/30">
                  VANILLA ICE CREAM
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {currentDevice.name}
              </p>
            </div>

            {/* Quick Game Turbo indicator if active */}
            {gameTurboActive && (
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-bold animate-pulse truncate max-w-[170px]">
                <span>🔥 TURBO +{gamesList.find((g) => g.id === selectedGame)?.dedicatedRamGb || 4}GB</span>
              </div>
            )}
          </div>
        </header>

        {/* Main Content View with Active Tab */}
        <main className="px-4 py-3 pb-24">
          {activeTab === 'overview' && (
            <QuickBoostTab
              stats={stats}
              processes={processes}
              onTriggerBoost={handleTriggerBoost}
              onQuickAction={handleQuickAction}
              language={language}
              isBoosting={isBoosting}
              lastBoostResult={lastBoostResult}
            />
          )}

          {activeTab === 'processes' && (
            <ProcessManagerTab
              processes={processes}
              onToggleProtect={handleToggleProtect}
              onToggleFreeze={handleToggleFreeze}
              onKillProcess={handleKillProcess}
              onKillAllCached={handleKillAllCached}
              onResetProcesses={handleResetProcesses}
              language={language}
            />
          )}

          {activeTab === 'virtual_ram' && (
            <VirtualRamTab
              stats={stats}
              virtualRamSizeGb={virtualRamSizeGb}
              onSetVirtualRamSize={setVirtualRamSizeGb}
              zramAlgorithm={zramAlgorithm}
              onSetAlgorithm={setZramAlgorithm}
              swappiness={swappiness}
              onSetSwappiness={setSwappiness}
              onCompactZram={() => handleQuickAction('zram')}
              language={language}
            />
          )}

          {activeTab === 'game_turbo' && (
            <GameTurboTab
              gameTurboActive={gameTurboActive}
              onToggleGameTurbo={handleToggleGameTurbo}
              selectedGameId={selectedGame}
              onSelectGame={setSelectedGame}
              gamesList={gamesList}
              onAddCustomGame={handleAddCustomGame}
              onUpdateGame={handleUpdateGame}
              onDeleteGame={handleDeleteGame}
              onRestoreDefaultGames={handleRestoreDefaultGames}
              installedProcesses={processes}
              lmkMode={lmkMode}
              onSetLmkMode={setLmkMode}
              language={language}
            />
          )}

          {activeTab === 'benchmark' && (
            <BenchmarkTab
              stats={stats}
              benchmark={benchmark}
              onUpdateBenchmark={setBenchmark}
              language={language}
            />
          )}

          {activeTab === 'settings' && (
            <SettingsTab
              settings={appSettings}
              onUpdateSettings={handleUpdateSettings}
              currentDevice={currentDevice}
              onSelectDevice={handleSelectDevice}
              language={language}
            />
          )}
        </main>

        {/* Bottom Navigation */}
        <Navigation
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          language={language}
        />

        {/* Interactive Boost Animation & Summary Modal */}
        <BoostModal
          isOpen={isBoostModalOpen}
          onClose={() => setIsBoostModalOpen(false)}
          result={lastBoostResult}
          language={language}
        />
      </div>
    </div>
  );
}
