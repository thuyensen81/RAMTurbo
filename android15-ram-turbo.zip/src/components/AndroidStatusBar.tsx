import { useState, useEffect } from 'react';
import { Wifi, BatteryMedium, Volume2, VolumeX, Smartphone, Monitor, Globe, Download } from 'lucide-react';
import { DeviceProfile } from '../types';
import { soundFX } from '../utils/audio';

interface AndroidStatusBarProps {
  device: DeviceProfile;
  soundEnabled: boolean;
  onToggleSound: () => void;
  language: 'vi' | 'en';
  onToggleLanguage: () => void;
  viewMode: 'responsive' | 'phone_mockup';
  onToggleViewMode: () => void;
}

export function AndroidStatusBar({
  device,
  soundEnabled,
  onToggleSound,
  language,
  onToggleLanguage,
  viewMode,
  onToggleViewMode,
}: AndroidStatusBarProps) {
  const [time, setTime] = useState<string>('09:41');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full bg-slate-950/80 backdrop-blur-md border-b border-emerald-500/20 px-4 py-2.5 flex items-center justify-between text-xs select-none sticky top-0 z-40 transition-colors">
      {/* Left: Clock & Android 15 Badge */}
      <div className="flex items-center gap-2.5">
        <span className="font-semibold text-slate-200 tracking-wider text-sm font-mono">{time}</span>
        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-medium text-[11px]">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>Android 15 API 35</span>
        </div>
      </div>

      {/* Center: Device model badge */}
      <div className="hidden sm:flex items-center gap-1.5 text-slate-400 font-medium truncate max-w-[200px] md:max-w-xs">
        <span className="truncate">{device.model}</span>
      </div>

      {/* Right: Quick Controls & Android Status icons */}
      <div className="flex items-center gap-3">
        {/* Export / Download ZIP */}
        <a
          href="/android15-ram-turbo.zip"
          download="android15-ram-turbo.zip"
          onClick={() => soundFX.playBoostComplete()}
          title={language === 'vi' ? 'Tải về file ZIP mã nguồn' : 'Download project ZIP'}
          className="flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold text-emerald-300 hover:text-white bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-500/40 transition shadow-sm"
        >
          <Download size={13} className="text-emerald-400" />
          <span>ZIP</span>
        </a>

        {/* View Mode Toggle */}
        <button
          onClick={() => {
            soundFX.playTap();
            onToggleViewMode();
          }}
          title={viewMode === 'phone_mockup' ? 'Chế độ Toàn màn hình' : 'Chế độ Khung điện thoại Android'}
          className="p-1 rounded-md text-slate-400 hover:text-cyan-400 hover:bg-slate-800 transition"
        >
          {viewMode === 'phone_mockup' ? <Monitor size={15} /> : <Smartphone size={15} />}
        </button>

        {/* Language Toggle */}
        <button
          onClick={() => {
            soundFX.playTap();
            onToggleLanguage();
          }}
          className="flex items-center gap-1 px-1.5 py-0.5 rounded text-[11px] font-bold text-slate-300 hover:text-white bg-slate-900 border border-slate-700/60 transition"
          title="Đổi ngôn ngữ / Change Language"
        >
          <Globe size={13} className="text-emerald-400" />
          <span>{language.toUpperCase()}</span>
        </button>

        {/* Sound Toggle */}
        <button
          onClick={() => {
            soundFX.playSwitch(!soundEnabled);
            onToggleSound();
          }}
          className="p-1 rounded-md text-slate-400 hover:text-emerald-400 hover:bg-slate-800 transition"
          title={soundEnabled ? 'Tắt âm thanh hiệu ứng' : 'Bật âm thanh hiệu ứng'}
        >
          {soundEnabled ? <Volume2 size={15} className="text-emerald-400" /> : <VolumeX size={15} />}
        </button>

        {/* 5G & Wifi */}
        <div className="flex items-center gap-1 text-slate-300">
          <span className="font-bold text-[10px] text-cyan-400 font-mono">5G</span>
          <Wifi size={14} className="text-slate-300" />
        </div>

        {/* Battery */}
        <div className="flex items-center gap-1 text-slate-300">
          <span className="text-[10px] font-mono text-emerald-400 font-bold">96%</span>
          <BatteryMedium size={15} className="text-emerald-400" />
        </div>
      </div>
    </div>
  );
}
