import { Zap, Layers, HardDrive, Flame, Gauge, Settings } from 'lucide-react';
import { soundFX } from '../utils/audio';

export type TabType = 'overview' | 'processes' | 'virtual_ram' | 'game_turbo' | 'benchmark' | 'settings';

interface NavigationProps {
  activeTab: TabType;
  onSelectTab: (tab: TabType) => void;
  language: 'vi' | 'en';
}

export function Navigation({ activeTab, onSelectTab, language }: NavigationProps) {
  const tabs = [
    {
      id: 'overview' as TabType,
      label: language === 'vi' ? 'Tổng Quan' : 'Overview',
      icon: Zap,
      activeColor: 'text-emerald-400',
      activeBg: 'bg-emerald-500/20 text-emerald-400',
    },
    {
      id: 'processes' as TabType,
      label: language === 'vi' ? 'Tiến Trình' : 'Processes',
      icon: Layers,
      activeColor: 'text-cyan-400',
      activeBg: 'bg-cyan-500/20 text-cyan-400',
    },
    {
      id: 'virtual_ram' as TabType,
      label: language === 'vi' ? 'RAM Ảo' : 'Virtual RAM',
      icon: HardDrive,
      activeColor: 'text-violet-400',
      activeBg: 'bg-violet-500/20 text-violet-400',
    },
    {
      id: 'game_turbo' as TabType,
      label: 'Game Turbo',
      icon: Flame,
      activeColor: 'text-rose-400',
      activeBg: 'bg-rose-500/20 text-rose-400',
    },
    {
      id: 'benchmark' as TabType,
      label: 'Benchmark',
      icon: Gauge,
      activeColor: 'text-amber-400',
      activeBg: 'bg-amber-500/20 text-amber-400',
    },
    {
      id: 'settings' as TabType,
      label: language === 'vi' ? 'Cài Đặt' : 'Settings',
      icon: Settings,
      activeColor: 'text-slate-200',
      activeBg: 'bg-slate-700/50 text-slate-200',
    },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/90 backdrop-blur-xl border-t border-slate-800/80 px-2 py-1.5 flex justify-around items-center max-w-lg mx-auto sm:max-w-2xl select-none">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;

        return (
          <button
            key={tab.id}
            onClick={() => {
              soundFX.playTap();
              onSelectTab(tab.id);
            }}
            className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-2xl transition-all duration-200 group ${
              isActive ? 'scale-105' : 'hover:text-slate-300'
            }`}
          >
            <div
              className={`p-1.5 rounded-xl transition-all ${
                isActive
                  ? tab.activeBg
                  : 'text-slate-500 group-hover:text-slate-300 group-hover:bg-slate-900'
              }`}
            >
              <Icon size={18} className={isActive ? 'stroke-[2.5]' : 'stroke-2'} />
            </div>
            <span
              className={`text-[10px] font-medium tracking-tight mt-0.5 transition-colors ${
                isActive ? 'text-white font-bold' : 'text-slate-500'
              }`}
            >
              {tab.label}
            </span>
          </button>
        );
      })}
    </div>
  );
}
