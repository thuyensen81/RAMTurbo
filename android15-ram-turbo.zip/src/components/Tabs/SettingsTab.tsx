import { AppSettings, DeviceProfile } from '../../types';
import { DEVICE_PROFILES } from '../../utils/mockData';
import { Settings, Sliders, Smartphone, Volume2, ShieldCheck, Cpu, Info, Check, Download, FileArchive } from 'lucide-react';
import { soundFX } from '../../utils/audio';

interface SettingsTabProps {
  settings: AppSettings;
  onUpdateSettings: (patch: Partial<AppSettings>) => void;
  currentDevice: DeviceProfile;
  onSelectDevice: (deviceId: string) => void;
  language: 'vi' | 'en';
}

export function SettingsTab({
  settings,
  onUpdateSettings,
  currentDevice,
  onSelectDevice,
  language,
}: SettingsTabProps) {
  return (
    <div className="space-y-5 pb-6">
      {/* Automation Rules */}
      <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800 rounded-3xl p-5 shadow-lg">
        <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-2">
          <Sliders size={14} className="text-emerald-400" />
          <span>{language === 'vi' ? 'Quy Tắc Tự Động Hóa' : 'Automated RAM Optimization'}</span>
        </h4>

        <div className="space-y-4">
          {/* Threshold auto boost */}
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="text-xs font-bold text-white">
                {language === 'vi'
                  ? 'Tự động dọn RAM khi vượt ngưỡng'
                  : 'Auto-boost when RAM exceeds threshold'}
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                {language === 'vi'
                  ? `Kích hoạt dọn dẹp nhẹ khi bộ nhớ đầy trên ${settings.autoBoostThresholdPercent}%`
                  : `Silently trims memory when usage hits ${settings.autoBoostThresholdPercent}%`}
              </div>
            </div>
            <button
              onClick={() => {
                soundFX.playSwitch(!settings.autoBoostEnabled);
                onUpdateSettings({ autoBoostEnabled: !settings.autoBoostEnabled });
              }}
              className={`w-12 h-6 rounded-full transition-colors p-0.5 shrink-0 ${
                settings.autoBoostEnabled ? 'bg-emerald-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.autoBoostEnabled ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Clean on screen lock */}
          <div className="flex items-center justify-between gap-3 pt-3 border-t border-slate-800/60">
            <div>
              <div className="text-xs font-bold text-white">
                {language === 'vi'
                  ? 'Tự động tăng tốc khi khoá màn hình'
                  : 'Auto-clean upon screen lock'}
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                {language === 'vi'
                  ? 'Giải phóng bộ nhớ đệm ngay khi tắt màn hình để tiết kiệm pin tối đa'
                  : 'Compacts background allocations whenever the screen turns off'}
              </div>
            </div>
            <button
              onClick={() => {
                soundFX.playSwitch(!settings.boostOnScreenLock);
                onUpdateSettings({ boostOnScreenLock: !settings.boostOnScreenLock });
              }}
              className={`w-12 h-6 rounded-full transition-colors p-0.5 shrink-0 ${
                settings.boostOnScreenLock ? 'bg-emerald-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.boostOnScreenLock ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Sound & Haptics */}
          <div className="flex items-center justify-between gap-3 pt-3 border-t border-slate-800/60">
            <div>
              <div className="text-xs font-bold text-white">
                {language === 'vi'
                  ? 'Âm thanh phản hồi xúc giác'
                  : 'Sound Effects & Haptic Audio'}
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                {language === 'vi'
                  ? 'Phát âm thanh mô phỏng tiến trình bộ nhớ và tăng tốc'
                  : 'Synthesized cyber audio feedback on UI actions'}
              </div>
            </div>
            <button
              onClick={() => {
                soundFX.playSwitch(!settings.soundEnabled);
                onUpdateSettings({ soundEnabled: !settings.soundEnabled });
              }}
              className={`w-12 h-6 rounded-full transition-colors p-0.5 shrink-0 ${
                settings.soundEnabled ? 'bg-emerald-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.soundEnabled ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      {/* Device Profile Switcher */}
      <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800 rounded-3xl p-5 shadow-lg">
        <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-2 flex items-center gap-2">
          <Smartphone size={14} className="text-cyan-400" />
          <span>{language === 'vi' ? 'Hồ Sơ Thiết Bị Mô Phỏng' : 'Simulated Device Profile'}</span>
        </h4>
        <p className="text-[11px] text-slate-400 mb-4">
          {language === 'vi'
            ? 'Thay đổi thiết bị để trải nghiệm khả năng quản lý RAM ở các mức dung lượng khác nhau (8GB - 24GB).'
            : 'Select device to experience Android 15 memory management across different hardware tiers.'}
        </p>

        <div className="space-y-2.5">
          {DEVICE_PROFILES.map((profile) => {
            const isSelected = profile.id === currentDevice.id;
            return (
              <div
                key={profile.id}
                onClick={() => {
                  soundFX.playTap();
                  onSelectDevice(profile.id);
                }}
                className={`p-3.5 rounded-2xl border cursor-pointer transition flex items-center justify-between ${
                  isSelected
                    ? 'bg-cyan-500/10 border-cyan-500/50 text-white'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white">{profile.name}</span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-400 font-mono font-bold">
                      {profile.totalRamGb} GB RAM
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                    {profile.chipset}
                  </div>
                </div>

                <div
                  className={`w-5 h-5 rounded-full flex items-center justify-center border ${
                    isSelected ? 'bg-cyan-500 border-cyan-400 text-slate-950' : 'border-slate-700'
                  }`}
                >
                  {isSelected && <Check size={12} strokeWidth={3} />}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Android 15 Kernel & Technical Specifications */}
      <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800 rounded-3xl p-5 shadow-lg">
        <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3 flex items-center gap-2">
          <Cpu size={14} className="text-purple-400" />
          <span>{language === 'vi' ? 'Thông Tin Kỹ Thuật Android 15' : 'Android 15 Kernel Specs'}</span>
        </h4>

        <div className="space-y-2 text-xs font-mono">
          <div className="flex justify-between py-1.5 border-b border-slate-800">
            <span className="text-slate-400">Android Version</span>
            <span className="text-white font-bold">{currentDevice.androidVersion}</span>
          </div>
          <div className="flex justify-between py-1.5 border-b border-slate-800">
            <span className="text-slate-400">API Level</span>
            <span className="text-emerald-400 font-bold">{currentDevice.apiLevel}</span>
          </div>
          <div className="flex justify-between py-1.5 border-b border-slate-800">
            <span className="text-slate-400">Kernel Version</span>
            <span className="text-slate-300 truncate max-w-[220px]">{currentDevice.kernelVersion}</span>
          </div>
          <div className="flex justify-between py-1.5 border-b border-slate-800">
            <span className="text-slate-400">Memory Page Size</span>
            <span className="text-cyan-400 font-bold">16KB (16384 bytes)</span>
          </div>
          <div className="flex justify-between py-1.5 border-b border-slate-800">
            <span className="text-slate-400">CONFIG_ARM64_16K_PAGES</span>
            <span className="text-emerald-400 font-bold">Enabled</span>
          </div>
          <div className="flex justify-between py-1.5">
            <span className="text-slate-400">ART 15 Compiler</span>
            <span className="text-violet-400 font-bold">dex2oat v15.2.0</span>
          </div>
        </div>
      </div>

      {/* Export Project ZIP Card */}
      <div className="bg-gradient-to-r from-emerald-950/40 via-slate-900 to-cyan-950/40 border border-emerald-500/30 rounded-3xl p-5 shadow-lg">
        <div className="flex items-start justify-between gap-4 mb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
              <FileArchive size={22} />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                {language === 'vi' ? 'Xuất Mã Nguồn Dự Án (.ZIP)' : 'Export Project Source Code (.ZIP)'}
              </h4>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {language === 'vi'
                  ? 'Gói toàn bộ mã nguồn React + Tailwind + Android 15 Memory Engine'
                  : 'Bundle complete React + Tailwind + Android 15 Memory Engine project'}
              </p>
            </div>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono font-bold">
            ~76 KB
          </span>
        </div>

        <a
          href="/android15-ram-turbo.zip"
          download="android15-ram-turbo.zip"
          onClick={() => soundFX.playBoostComplete()}
          className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-black text-xs tracking-wider uppercase flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-98 transition"
        >
          <Download size={16} />
          <span>{language === 'vi' ? 'TẢI FILE ZIP VỀ MÁY NGAY' : 'DOWNLOAD ZIP ARCHIVE NOW'}</span>
        </a>
      </div>
    </div>
  );
}
