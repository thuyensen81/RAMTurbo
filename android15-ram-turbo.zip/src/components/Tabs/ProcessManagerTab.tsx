import { useState, useMemo } from 'react';
import { AppProcess } from '../../types';
import { Search, Shield, ShieldAlert, Snowflake, XCircle, RefreshCw, Trash2, CheckCircle2, AlertCircle } from 'lucide-react';
import { soundFX } from '../../utils/audio';

interface ProcessManagerTabProps {
  processes: AppProcess[];
  onToggleProtect: (id: string) => void;
  onToggleFreeze: (id: string) => void;
  onKillProcess: (id: string) => void;
  onKillAllCached: () => void;
  onResetProcesses: () => void;
  language: 'vi' | 'en';
}

export function ProcessManagerTab({
  processes,
  onToggleProtect,
  onToggleFreeze,
  onKillProcess,
  onKillAllCached,
  onResetProcesses,
  language,
}: ProcessManagerTabProps) {
  const [search, setSearch] = useState<string>('');
  const [filter, setFilter] = useState<'all' | 'heavy' | 'background' | 'frozen'>('all');

  const filteredProcesses = useMemo(() => {
    return processes.filter((p) => {
      // Search
      const matchesSearch =
        p.name.toLowerCase().includes(search.toLowerCase()) ||
        p.packageName.toLowerCase().includes(search.toLowerCase());
      if (!matchesSearch) return false;

      // Filter
      if (filter === 'heavy') return p.ramUsageMb >= 500 && !p.isKilled;
      if (filter === 'background') return (p.priority === 'cached' || p.priority === 'phantom') && !p.isKilled;
      if (filter === 'frozen') return p.isFrozen && !p.isKilled;
      return true;
    });
  }, [processes, search, filter]);

  const totalKillableMb = useMemo(() => {
    return processes
      .filter((p) => !p.isProtected && !p.isKilled && (p.priority === 'cached' || p.priority === 'phantom'))
      .reduce((acc, p) => acc + p.ramUsageMb, 0);
  }, [processes]);

  return (
    <div className="space-y-4 pb-6">
      {/* Header & Batch Controls */}
      <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800 rounded-3xl p-5 shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="text-base font-bold text-white">
              {language === 'vi' ? 'Tiến Trình & Ứng Dụng Đang Chạy' : 'Active Processes & Tasks'}
            </h3>
            <p className="text-xs text-slate-400">
              {language === 'vi'
                ? `Có thể giải phóng ngay ~${totalKillableMb} MB từ ứng dụng ngầm`
                : `~${totalKillableMb} MB reclaimable from background apps`}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                soundFX.playTap();
                onKillAllCached();
              }}
              disabled={totalKillableMb === 0}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
                totalKillableMb === 0
                  ? 'bg-slate-800 text-slate-600 cursor-not-allowed'
                  : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md shadow-emerald-500/20 active:scale-95'
              }`}
            >
              <Trash2 size={14} />
              <span>{language === 'vi' ? 'Dọn Tất Cả Ứng Dụng Ngầm' : 'Kill All Cached Apps'}</span>
            </button>

            <button
              onClick={() => {
                soundFX.playTap();
                onResetProcesses();
              }}
              title="Khôi phục trạng thái ban đầu"
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
            >
              <RefreshCw size={14} />
            </button>
          </div>
        </div>

        {/* Search input */}
        <div className="relative mb-3">
          <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={
              language === 'vi' ? 'Tìm theo tên ứng dụng hoặc package ID...' : 'Search app or package name...'
            }
            className="w-full bg-slate-950/80 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
          />
          {search && (
            <button
              onClick={() => setSearch('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white"
            >
              ×
            </button>
          )}
        </div>

        {/* Filter chips */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1.5 rounded-lg font-medium transition ${
              filter === 'all'
                ? 'bg-emerald-500 text-slate-950 font-bold'
                : 'bg-slate-800/80 text-slate-400 hover:text-white'
            }`}
          >
            {language === 'vi' ? 'Tất cả' : 'All'} ({processes.length})
          </button>
          <button
            onClick={() => setFilter('heavy')}
            className={`px-3 py-1.5 rounded-lg font-medium transition ${
              filter === 'heavy'
                ? 'bg-emerald-500 text-slate-950 font-bold'
                : 'bg-slate-800/80 text-slate-400 hover:text-white'
            }`}
          >
            {language === 'vi' ? 'Ăn nhiều RAM (>500MB)' : 'Heavy RAM (>500MB)'}
          </button>
          <button
            onClick={() => setFilter('background')}
            className={`px-3 py-1.5 rounded-lg font-medium transition ${
              filter === 'background'
                ? 'bg-emerald-500 text-slate-950 font-bold'
                : 'bg-slate-800/80 text-slate-400 hover:text-white'
            }`}
          >
            {language === 'vi' ? 'Chạy ngầm (Cached)' : 'Background (Cached)'}
          </button>
          <button
            onClick={() => setFilter('frozen')}
            className={`px-3 py-1.5 rounded-lg font-medium transition ${
              filter === 'frozen'
                ? 'bg-emerald-500 text-slate-950 font-bold'
                : 'bg-slate-800/80 text-slate-400 hover:text-white'
            }`}
          >
            {language === 'vi' ? 'Đã đóng băng' : 'Frozen'} (
            {processes.filter((p) => p.isFrozen && !p.isKilled).length})
          </button>
        </div>
      </div>

      {/* Processes List */}
      <div className="space-y-2.5">
        {filteredProcesses.map((p) => {
          const isKilled = p.isKilled;
          const isFrozen = p.isFrozen;
          const isProtected = p.isProtected;

          return (
            <div
              key={p.id}
              className={`p-3.5 rounded-2xl border transition-all ${
                isKilled
                  ? 'bg-slate-950/40 border-slate-900 opacity-40'
                  : isFrozen
                  ? 'bg-cyan-950/20 border-cyan-800/40'
                  : isProtected
                  ? 'bg-slate-900/70 border-emerald-500/20'
                  : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between gap-3">
                {/* Left: Icon & Info */}
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 shadow ${
                      isFrozen
                        ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40'
                        : isKilled
                        ? 'bg-slate-800 text-slate-600'
                        : p.category === 'games'
                        ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                        : p.category === 'social'
                        ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                        : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    }`}
                  >
                    {isFrozen ? (
                      <Snowflake size={18} className="animate-pulse" />
                    ) : isKilled ? (
                      <XCircle size={18} />
                    ) : (
                      p.name.substring(0, 2).toUpperCase()
                    )}
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h4
                        className={`text-xs font-bold truncate ${
                          isKilled ? 'line-through text-slate-500' : 'text-white'
                        }`}
                      >
                        {p.name}
                      </h4>

                      {/* 16KB Page Badge */}
                      {p.page16kbAligned ? (
                        <span className="text-[9px] px-1 py-0.2 rounded bg-emerald-500/10 text-emerald-400 font-mono border border-emerald-500/20 shrink-0">
                          16KB
                        </span>
                      ) : (
                        <span className="text-[9px] px-1 py-0.2 rounded bg-amber-500/10 text-amber-400 font-mono border border-amber-500/20 shrink-0" title="Chưa căn chỉnh 16KB page">
                          4KB
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2 text-[10px] text-slate-400 truncate mt-0.5">
                      <span className="font-mono truncate">{p.packageName}</span>
                      <span>•</span>
                      <span className="capitalize text-slate-400">{p.priority}</span>
                    </div>
                  </div>
                </div>

                {/* Right: RAM Badge & Quick Action Buttons */}
                <div className="flex items-center gap-2 shrink-0">
                  <div className="text-right mr-1">
                    <div
                      className={`text-xs font-mono font-bold ${
                        isKilled
                          ? 'text-slate-600'
                          : isFrozen
                          ? 'text-cyan-400'
                          : p.ramUsageMb > 600
                          ? 'text-rose-400'
                          : 'text-emerald-400'
                      }`}
                    >
                      {isKilled
                        ? '0 MB'
                        : isFrozen
                        ? `${Math.round(p.ramUsageMb * 0.15)} MB`
                        : `${p.ramUsageMb} MB`}
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono">
                      CPU {isKilled ? '0%' : isFrozen ? '0.1%' : `${p.cpuPercent}%`}
                    </div>
                  </div>

                  {/* Whitelist / Protect Button */}
                  <button
                    onClick={() => {
                      soundFX.playTap();
                      onToggleProtect(p.id);
                    }}
                    title={
                      isProtected
                        ? 'Đang được bảo vệ (Whitelist). Nhấn để bỏ bảo vệ.'
                        : 'Thêm vào Whitelist (Không bị dọn khi tăng tốc)'
                    }
                    className={`p-2 rounded-xl transition ${
                      isProtected
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                        : 'bg-slate-800/80 text-slate-500 hover:text-slate-300'
                    }`}
                  >
                    <Shield size={14} className={isProtected ? 'fill-emerald-500/30' : ''} />
                  </button>

                  {/* Freeze Button */}
                  {p.canKill && !isKilled && (
                    <button
                      onClick={() => {
                        soundFX.playTap();
                        onToggleFreeze(p.id);
                      }}
                      title={isFrozen ? 'Rã đông ứng dụng' : 'Đóng băng ứng dụng (tiết kiệm 85% RAM)'}
                      className={`p-2 rounded-xl transition ${
                        isFrozen
                          ? 'bg-cyan-500 text-slate-950 font-bold'
                          : 'bg-slate-800/80 text-slate-400 hover:text-cyan-400'
                      }`}
                    >
                      <Snowflake size={14} />
                    </button>
                  )}

                  {/* Kill Button */}
                  {p.canKill && (
                    <button
                      onClick={() => {
                        soundFX.playTap();
                        onKillProcess(p.id);
                      }}
                      disabled={isProtected || isKilled}
                      title={
                        isProtected
                          ? 'Ứng dụng này đang được bảo vệ'
                          : isKilled
                          ? 'Ứng dụng đã bị tắt'
                          : 'Dừng ngay lập tức'
                      }
                      className={`p-2 rounded-xl transition ${
                        isKilled
                          ? 'bg-slate-800/40 text-slate-700 cursor-not-allowed'
                          : isProtected
                          ? 'bg-slate-800/40 text-slate-700 cursor-not-allowed'
                          : 'bg-slate-800/80 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10'
                      }`}
                    >
                      <XCircle size={14} />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
