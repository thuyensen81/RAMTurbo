import { useState, useRef, useEffect } from 'react';
import { BenchmarkMetrics, RAMStats } from '../../types';
import { Gauge, Play, CheckCircle2, Cpu, Activity, Zap, HardDrive, Sparkles } from 'lucide-react';
import { soundFX } from '../../utils/audio';

interface BenchmarkTabProps {
  stats: RAMStats;
  benchmark: BenchmarkMetrics;
  onUpdateBenchmark: (results: BenchmarkMetrics) => void;
  language: 'vi' | 'en';
}

export function BenchmarkTab({
  stats,
  benchmark,
  onUpdateBenchmark,
  language,
}: BenchmarkTabProps) {
  const [isRunning, setIsRunning] = useState(false);
  const [currentPhase, setCurrentPhase] = useState<string>('');
  const [progress, setProgress] = useState<number>(0);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Canvas visualizer during benchmark
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let offset = 0;

    const draw = () => {
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      // Draw memory block visualizer
      const cols = 24;
      const rows = 6;
      const blockW = (w - (cols + 1) * 3) / cols;
      const blockH = (h - (rows + 1) * 3) / rows;

      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const x = 3 + c * (blockW + 3);
          const y = 3 + r * (blockH + 3);

          if (isRunning) {
            const activeIndex = Math.floor((offset * 2 + r * cols + c) % (rows * cols));
            const isRead = activeIndex % 3 === 0;
            ctx.fillStyle = isRead ? '#10b981' : '#06b6d4';
            ctx.shadowColor = isRead ? '#10b981' : '#06b6d4';
            ctx.shadowBlur = 6;
          } else {
            ctx.fillStyle = (r * cols + c) % 4 === 0 ? '#1e293b' : '#0f172a';
            ctx.shadowBlur = 0;
          }

          ctx.fillRect(x, y, blockW, blockH);
        }
      }

      offset += 0.2;
      animId = requestAnimationFrame(draw);
    };

    draw();

    return () => cancelAnimationFrame(animId);
  }, [isRunning]);

  const runBenchmark = () => {
    soundFX.playWhoosh();
    setIsRunning(true);
    setProgress(0);

    const phases = language === 'vi'
      ? [
          'Đo thông lượng đọc tuần tự (Sequential Read)...',
          'Đo thông lượng ghi dữ liệu ngẫu nhiên (Random Write)...',
          'Kiểm tra độ trễ truy xuất trang nhớ 16KB (TLB Latency)...',
          'Đánh giá phân mảnh bộ nhớ thực tế...',
        ]
      : [
          'Measuring Sequential Read Throughput...',
          'Measuring Random 16KB Write Cycles...',
          'Measuring TLB Access Latency...',
          'Evaluating Page Table Defragmentation...',
        ];

    let currentIdx = 0;
    setCurrentPhase(phases[0]);

    const interval = setInterval(() => {
      setProgress((prev) => {
        const next = prev + 4;
        if (next >= 25 && currentIdx === 0) {
          currentIdx = 1;
          setCurrentPhase(phases[1]);
          soundFX.playTap();
        } else if (next >= 50 && currentIdx === 1) {
          currentIdx = 2;
          setCurrentPhase(phases[2]);
          soundFX.playTap();
        } else if (next >= 75 && currentIdx === 2) {
          currentIdx = 3;
          setCurrentPhase(phases[3]);
          soundFX.playTap();
        }

        if (next >= 100) {
          clearInterval(interval);
          setIsRunning(false);
          soundFX.playBoostComplete();

          // Calculate realistic Android 15 LPDDR5X numbers
          const isCompacted = stats.fragmentationPercent <= 12;
          const readSpeed = 52.4 + Number((Math.random() * 3.5).toFixed(1));
          const writeSpeed = 44.8 + Number((Math.random() * 2.8).toFixed(1));
          const latency = isCompacted ? 36.2 : 44.1;
          const frag = stats.fragmentationPercent;
          const pageScore = 98;
          const overall = Math.min(99, Math.round(85 + (readSpeed / 60) * 10 + (isCompacted ? 5 : 0)));

          onUpdateBenchmark({
            readSpeedGbps: readSpeed,
            writeSpeedGbps: writeSpeed,
            latencyNs: latency,
            fragmentationPercent: frag,
            page16kbScore: pageScore,
            overallScore: overall,
            testedAt: new Date(),
          });
          return 100;
        }
        return next;
      });
    }, 80);
  };

  return (
    <div className="space-y-5 pb-6">
      {/* Benchmark Header Card */}
      <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800 rounded-3xl p-6 shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h3 className="text-base font-bold text-white">
                {language === 'vi' ? 'Đo Tốc Độ & Kiểm Tra Sức Khỏe RAM' : 'RAM Speed & Health Benchmark'}
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-mono border border-emerald-500/20">
                LPDDR5X 8533Mbps
              </span>
            </div>
            <p className="text-xs text-slate-400">
              {language === 'vi'
                ? 'Thực hiện các bài test đọc/ghi dữ liệu thực tế và đo độ trễ chuẩn Android 15.'
                : 'Runs real-time read/write throughput tests and evaluates 16KB page efficiency.'}
            </p>
          </div>

          <div className="text-right">
            <div className="text-3xl font-black font-mono text-emerald-400">
              {benchmark.overallScore}
              <span className="text-xs font-normal text-slate-400"> /100</span>
            </div>
            <div className="text-[10px] text-slate-400">
              {benchmark.testedAt
                ? `${language === 'vi' ? 'Vừa đo lúc' : 'Tested at'} ${new Date(benchmark.testedAt).toLocaleTimeString()}`
                : language === 'vi' ? 'Chưa kiểm tra gần đây' : 'Not tested recently'}
            </div>
          </div>
        </div>

        {/* Live Block Visualizer Canvas */}
        <div className="w-full h-24 bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 p-1 mb-4">
          <canvas ref={canvasRef} width={640} height={96} className="w-full h-full block" />
        </div>

        {/* Action Button & Phase */}
        <div className="space-y-3">
          {isRunning && (
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-cyan-400 truncate font-semibold">{currentPhase}</span>
                <span className="text-white font-bold">{progress}%</span>
              </div>
              <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-emerald-400 to-cyan-400 h-full rounded-full transition-all duration-100"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}

          <button
            onClick={runBenchmark}
            disabled={isRunning}
            className={`w-full py-4 rounded-2xl font-bold text-xs sm:text-sm tracking-wider uppercase transition-all flex items-center justify-center gap-2.5 shadow-lg ${
              isRunning
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                : 'bg-gradient-to-r from-cyan-500 via-teal-500 to-emerald-500 hover:from-cyan-400 hover:to-emerald-400 text-slate-950 shadow-cyan-500/20 active:scale-98'
            }`}
          >
            <Play size={16} className={isRunning ? 'animate-spin' : ''} />
            <span>
              {isRunning
                ? language === 'vi'
                  ? 'ĐANG THỰC HIỆN BÀI TEST...'
                  : 'BENCHMARKING IN PROGRESS...'
                : language === 'vi'
                ? 'BẮT ĐẦU KIỂM TRA TỐC ĐỘ RAM'
                : 'RUN RAM BENCHMARK'}
            </span>
          </button>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 gap-3">
        {/* Read Speed */}
        <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
          <div className="flex items-center gap-2 text-slate-400 text-xs mb-1">
            <Zap size={14} className="text-emerald-400" />
            <span>{language === 'vi' ? 'Tốc độ Đọc (Read)' : 'Read Throughput'}</span>
          </div>
          <div className="text-2xl font-black font-mono text-emerald-400">
            {benchmark.readSpeedGbps} <span className="text-xs font-normal">GB/s</span>
          </div>
          <div className="text-[10px] text-slate-500 mt-1">
            {language === 'vi' ? 'Chuẩn LPDDR5X 4 kênh' : 'Quad-channel LPDDR5X'}
          </div>
        </div>

        {/* Write Speed */}
        <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
          <div className="flex items-center gap-2 text-slate-400 text-xs mb-1">
            <Activity size={14} className="text-cyan-400" />
            <span>{language === 'vi' ? 'Tốc độ Ghi (Write)' : 'Write Throughput'}</span>
          </div>
          <div className="text-2xl font-black font-mono text-cyan-400">
            {benchmark.writeSpeedGbps} <span className="text-xs font-normal">GB/s</span>
          </div>
          <div className="text-[10px] text-slate-500 mt-1">
            {language === 'vi' ? 'Bộ nhớ đệm ghi nhanh' : 'Zero-copy write pipeline'}
          </div>
        </div>

        {/* Latency */}
        <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
          <div className="flex items-center gap-2 text-slate-400 text-xs mb-1">
            <Cpu size={14} className="text-violet-400" />
            <span>{language === 'vi' ? 'Độ trễ truy xuất' : 'Access Latency'}</span>
          </div>
          <div className="text-2xl font-black font-mono text-violet-400">
            {benchmark.latencyNs} <span className="text-xs font-normal">ns</span>
          </div>
          <div className="text-[10px] text-slate-500 mt-1">
            {benchmark.latencyNs < 40 ? '⚡ Siêu nhanh (Không lag)' : 'Mức bình thường'}
          </div>
        </div>

        {/* 16KB Page Alignment */}
        <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
          <div className="flex items-center gap-2 text-slate-400 text-xs mb-1">
            <Sparkles size={14} className="text-amber-400" />
            <span>{language === 'vi' ? 'Tương thích Trang 16KB' : '16KB Page Score'}</span>
          </div>
          <div className="text-2xl font-black font-mono text-amber-400">
            {benchmark.page16kbScore}%
          </div>
          <div className="text-[10px] text-slate-500 mt-1">
            {language === 'vi' ? 'Chuẩn Android 15 mới' : 'Native Android 15 standard'}
          </div>
        </div>
      </div>
    </div>
  );
}
