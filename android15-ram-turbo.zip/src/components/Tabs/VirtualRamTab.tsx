import { useState } from 'react';
import { RAMStats, CompressionAlgorithm } from '../../types';
import { HardDrive, Zap, Cpu, Sparkles, RefreshCw, Info, CheckCircle2 } from 'lucide-react';
import { soundFX } from '../../utils/audio';

interface VirtualRamTabProps {
  stats: RAMStats;
  virtualRamSizeGb: number;
  onSetVirtualRamSize: (gb: number) => void;
  zramAlgorithm: CompressionAlgorithm;
  onSetAlgorithm: (algo: CompressionAlgorithm) => void;
  swappiness: number;
  onSetSwappiness: (val: number) => void;
  onCompactZram: () => void;
  language: 'vi' | 'en';
}

export function VirtualRamTab({
  stats,
  virtualRamSizeGb,
  onSetVirtualRamSize,
  zramAlgorithm,
  onSetAlgorithm,
  swappiness,
  onSetSwappiness,
  onCompactZram,
  language,
}: VirtualRamTabProps) {
  const [isCompacting, setIsCompacting] = useState(false);
  const [compactDone, setCompactDone] = useState(false);

  const sizes = [0, 2, 4, 6, 8, 12];

  const handleCompact = () => {
    soundFX.playTap();
    setIsCompacting(true);
    setCompactDone(false);
    setTimeout(() => {
      onCompactZram();
      setIsCompacting(false);
      setCompactDone(true);
      soundFX.playBoostComplete();
      setTimeout(() => setCompactDone(false), 3000);
    }, 1200);
  };

  const compressionRatio = zramAlgorithm === 'ZSTD' ? '3.1 : 1' : zramAlgorithm === 'LZ4' ? '2.3 : 1' : '2.1 : 1';

  return (
    <div className="space-y-5 pb-6">
      {/* Overview Card */}
      <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800 rounded-3xl p-5 shadow-lg relative overflow-hidden">
        <div className="flex items-start justify-between gap-4 mb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h3 className="text-base font-bold text-white">
                {language === 'vi' ? 'Công Nghệ RAM Ảo & zRAM Swap' : 'Virtual RAM & zRAM Engine'}
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 font-mono border border-cyan-500/20">
                UFS 4.0 Ready
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              {language === 'vi'
                ? 'Sử dụng chip nhớ UFS tốc độ cao để tạo phân vùng RAM nén mở rộng, cho phép giữ hàng chục ứng dụng chạy ngầm không bị tải lại.'
                : 'Leverages high-speed UFS storage to create a compressed in-memory swap device, keeping dozens of apps in memory without cold reloads.'}
            </p>
          </div>

          <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 shrink-0">
            <HardDrive size={24} />
          </div>
        </div>

        {/* Swap Usage Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-4">
          <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
            <div className="text-[10px] text-slate-400 mb-0.5">
              {language === 'vi' ? 'Tổng RAM Ảo' : 'Total Swap'}
            </div>
            <div className="text-lg font-bold font-mono text-cyan-400">
              {virtualRamSizeGb === 0 ? 'TẮT (0 GB)' : `+${virtualRamSizeGb} GB`}
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
            <div className="text-[10px] text-slate-400 mb-0.5">
              {language === 'vi' ? 'Swap Đang Dùng' : 'Used Swap'}
            </div>
            <div className="text-lg font-bold font-mono text-emerald-400">
              {stats.zramUsedMb} <span className="text-xs">MB</span>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 col-span-2 sm:col-span-1">
            <div className="text-[10px] text-slate-400 mb-0.5">
              {language === 'vi' ? 'Tỉ lệ nén trung bình' : 'Compression Ratio'}
            </div>
            <div className="text-lg font-bold font-mono text-violet-400">
              {compressionRatio}
            </div>
          </div>
        </div>

        {/* Compact Button */}
        <button
          onClick={handleCompact}
          disabled={isCompacting || virtualRamSizeGb === 0}
          className={`w-full py-3 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition ${
            virtualRamSizeGb === 0
              ? 'bg-slate-800 text-slate-600 cursor-not-allowed'
              : compactDone
              ? 'bg-emerald-500 text-slate-950'
              : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 active:scale-95'
          }`}
        >
          {isCompacting ? (
            <>
              <RefreshCw size={14} className="animate-spin" />
              <span>{language === 'vi' ? 'Đang nén và giải phóng swap...' : 'Compacting swap cache...'}</span>
            </>
          ) : compactDone ? (
            <>
              <CheckCircle2 size={14} />
              <span>{language === 'vi' ? 'Đã thu gọn zRAM thành công!' : 'zRAM compacted successfully!'}</span>
            </>
          ) : (
            <>
              <Zap size={14} />
              <span>{language === 'vi' ? 'Thu gọn & Nén zRAM ngay' : 'Trigger zRAM Compaction Now'}</span>
            </>
          )}
        </button>
      </div>

      {/* Select Virtual RAM Size */}
      <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800 rounded-3xl p-5 shadow-lg">
        <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-2">
          {language === 'vi' ? 'Tuỳ Chọn Kích Thước RAM Ảo (RAM Plus)' : 'Virtual RAM Size (RAM Plus)'}
        </h4>
        <p className="text-[11px] text-slate-400 mb-4">
          {language === 'vi'
            ? 'Khuyến nghị: Chọn +6GB hoặc +8GB cho thiết bị chơi game nặng và đa nhiệm 10+ app.'
            : 'Recommended: +6GB or +8GB for heavy gaming and 10+ multitasking apps.'}
        </p>

        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
          {sizes.map((s) => {
            const isSelected = virtualRamSizeGb === s;
            return (
              <button
                key={s}
                onClick={() => {
                  soundFX.playTap();
                  onSetVirtualRamSize(s);
                }}
                className={`py-3 px-2 rounded-2xl border text-center transition-all ${
                  isSelected
                    ? 'bg-emerald-500 text-slate-950 font-black border-emerald-400 shadow-lg shadow-emerald-500/20'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
                }`}
              >
                <div className="text-sm font-mono">{s === 0 ? 'OFF' : `+${s}GB`}</div>
                <div className={`text-[10px] mt-0.5 ${isSelected ? 'text-slate-900 font-semibold' : 'text-slate-500'}`}>
                  {s === 0 ? 'Không dùng' : `${s * 1024}MB`}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Compression Algorithm Selector */}
      <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800 rounded-3xl p-5 shadow-lg">
        <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-2">
          {language === 'vi' ? 'Thuật Toán Nén zRAM' : 'zRAM Compression Algorithm'}
        </h4>
        <p className="text-[11px] text-slate-400 mb-4">
          {language === 'vi'
            ? 'Android 15 hỗ trợ chuẩn nén LZ4 thế hệ mới và ZSTD siêu mật độ.'
            : 'Android 15 supports high-speed LZ4 and ultra-dense ZSTD compression.'}
        </p>

        <div className="space-y-2.5">
          {/* LZ4 */}
          <div
            onClick={() => {
              soundFX.playTap();
              onSetAlgorithm('LZ4');
            }}
            className={`p-3.5 rounded-2xl border cursor-pointer transition ${
              zramAlgorithm === 'LZ4'
                ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300'
                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="font-bold text-xs text-white">LZ4 (Khuyến nghị cho Gaming)</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-semibold">
                Độ trễ thấp nhất
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              {language === 'vi'
                ? 'Tốc độ giải nén siêu thanh (~4,500 MB/s), đảm bảo không giật lag khung hình khi chơi game.'
                : 'Ultra-fast decompression (~4,500 MB/s), avoiding frame drops in competitive games.'}
            </p>
          </div>

          {/* ZSTD */}
          <div
            onClick={() => {
              soundFX.playTap();
              onSetAlgorithm('ZSTD');
            }}
            className={`p-3.5 rounded-2xl border cursor-pointer transition ${
              zramAlgorithm === 'ZSTD'
                ? 'bg-cyan-500/10 border-cyan-500/40 text-cyan-300'
                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="font-bold text-xs text-white">ZSTD (Siêu tiết kiệm RAM)</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-400 font-semibold">
                Tỉ lệ nén 3.1:1
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              {language === 'vi'
                ? 'Nén dữ liệu chặt chẽ gấp 1.5 lần LZ4, giữ được số lượng ứng dụng ngầm khổng lồ.'
                : '1.5x higher compression than LZ4, ideal for heavy social media and browsing.'}
            </p>
          </div>

          {/* LZO-RLE */}
          <div
            onClick={() => {
              soundFX.playTap();
              onSetAlgorithm('LZO-RLE');
            }}
            className={`p-3.5 rounded-2xl border cursor-pointer transition ${
              zramAlgorithm === 'LZO-RLE'
                ? 'bg-violet-500/10 border-violet-500/40 text-violet-300'
                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="font-bold text-xs text-white">LZO-RLE (Linux Standard)</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-violet-500/20 text-violet-400 font-semibold">
                Mặc định AOSP
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              {language === 'vi'
                ? 'Cấu hình chuẩn của nhân Linux AOSP, cân bằng giữa thời lượng pin và bộ nhớ.'
                : 'Standard Linux kernel default, balancing battery consumption and performance.'}
            </p>
          </div>
        </div>
      </div>

      {/* Swappiness Slider */}
      <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800 rounded-3xl p-5 shadow-lg">
        <div className="flex items-center justify-between mb-2">
          <h4 className="text-xs font-bold text-white uppercase tracking-wider">
            {language === 'vi' ? 'Mức Độ Ưu Tiên Swap (vm.swappiness)' : 'Kernel Swappiness Level'}
          </h4>
          <span className="text-sm font-mono font-bold text-emerald-400">{swappiness}%</span>
        </div>

        <p className="text-[11px] text-slate-400 mb-4">
          {language === 'vi'
            ? 'Điều chỉnh mức độ chuyển dữ liệu ứng dụng không hoạt động sang zRAM để chừa chỗ cho RAM thật.'
            : 'Controls how aggressively the Android kernel moves inactive process pages into zRAM swap.'}
        </p>

        <input
          type="range"
          min="10"
          max="100"
          step="5"
          value={swappiness}
          onChange={(e) => {
            soundFX.playTap();
            onSetSwappiness(parseInt(e.target.value));
          }}
          className="w-full h-2 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-emerald-500"
        />

        <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-2">
          <span>10% (Chỉ dùng khi cạn RAM)</span>
          <span className="text-emerald-400 font-semibold">60% (Cân bằng Android 15)</span>
          <span>100% (Tối đa hóa)</span>
        </div>
      </div>
    </div>
  );
}
